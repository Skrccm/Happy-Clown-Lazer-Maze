import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;
import javax.imageio.stream.*;
public class LaserButton extends JButton implements ActionListener
{
  /**
   * Stores the Serial Version UID. 
   */
  private static final long serialVersionUID = 1L;
  javax.swing.Timer timer;
  private int counter=1;
  private LaserGrid parent;
  private int position;
  private ImageIcon[] images;
  public LaserButton(LaserGrid parent)
  { 
    this.parent=parent;
    setBorder (null);
    setBorderPainted(false);
    setFocusable(false);
    setBackground(Color.WHITE);
    setPreferredSize(new Dimension(52,52));
    timer=new javax.swing.Timer(1,this);
  }
  public void draw(ImageIcon[] image,int pos)
  { 
    this.images=image;
    this.position=pos;
    counter=-1;
  }
  public void draw()
  {
    timer.start();
  }
  public void actionPerformed(ActionEvent ae)
  {
    counter++;
    setIcon((images[counter]));
    if(counter==49||!parent.isDrawing())
    {
      timer.stop();
      parent.run(position+1);
      return;
    }
  }
}